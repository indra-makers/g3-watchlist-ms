package com.co.indra.coinmarketcap.watchlist.config;

public class Config {
}
