package com.co.indra.coinmarketcap.watchlist.services;
import org.springframework.stereotype.Service;


@Service
public class WatListService {
}
