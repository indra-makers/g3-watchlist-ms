package com.co.indra.coinmarketcap.watchlist.controllers;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class WatchListController {
}
